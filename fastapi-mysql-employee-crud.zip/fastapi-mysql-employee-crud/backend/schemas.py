from datetime import date
from pydantic import BaseModel, EmailStr


class EmployeeBase(BaseModel):
    name: str
    email: EmailStr
    department: str | None = None
    salary: float | None = None
    hire_date: date | None = None


class EmployeeCreate(EmployeeBase):
    pass


class EmployeeUpdate(BaseModel):
    name: str | None = None
    department: str | None = None
    salary: float | None = None
    hire_date: date | None = None


class EmployeeOut(EmployeeBase):
    id: int

    class Config:
        from_attributes = True
