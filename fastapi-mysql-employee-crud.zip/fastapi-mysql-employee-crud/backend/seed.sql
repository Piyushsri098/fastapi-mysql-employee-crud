CREATE TABLE IF NOT EXISTS employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  department VARCHAR(50),
  salary DECIMAL(10,2),
  hire_date DATE
);

INSERT INTO employees (name, email, department, salary, hire_date) VALUES
('Aarav Sharma','aarav.sharma@example.com','Engineering',75000,'2022-03-01'),
('Diya Patel','diya.patel@example.com','Marketing',62000,'2021-07-15'),
('Vihaan Rao','vihaan.rao@example.com','Engineering',80000,'2020-11-20'),
('Ananya Singh','ananya.singh@example.com','HR',55000,'2023-01-10'),
('Kabir Mehta','kabir.mehta@example.com','Sales',58000,'2019-06-05'),
('Ishita Gupta','ishita.gupta@example.com','Finance',70000,'2022-09-12'),
('Arjun Nair','arjun.nair@example.com','Engineering',82000,'2021-02-28'),
('Sara Khan','sara.khan@example.com','Marketing',60000,'2023-05-19'),
('Rohan Verma','rohan.verma@example.com','Sales',59000,'2020-08-08'),
('Meera Iyer','meera.iyer@example.com','Finance',72000,'2022-12-01'),
('Aditya Joshi','aditya.joshi@example.com','Engineering',78000,'2021-10-04'),
('Priya Reddy','priya.reddy@example.com','HR',54000,'2023-02-22'),
('Karan Malhotra','karan.malhotra@example.com','Sales',61000,'2019-09-17'),
('Neha Kapoor','neha.kapoor@example.com','Marketing',63000,'2022-04-25'),
('Siddharth Bose','siddharth.bose@example.com','Finance',74000,'2020-01-30');
