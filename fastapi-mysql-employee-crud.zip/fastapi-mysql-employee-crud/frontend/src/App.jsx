import { useEffect, useState } from "react";
import API from "./api";

const emptyForm = {
  name: "",
  email: "",
  department: "",
  salary: "",
  hire_date: "",
};

export default function App() {
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const res = await API.get("/employees");
      setEmployees(res.data);
    } catch (err) {
      setError("Could not reach the API. Is FastAPI running on :8000?");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  const handleChange = (field) => (e) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const startEdit = (emp) => {
    setEditingId(emp.id);
    setForm({
      name: emp.name,
      email: emp.email,
      department: emp.department || "",
      salary: emp.salary != null ? String(emp.salary) : "",
      hire_date: emp.hire_date || "",
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setForm(emptyForm);
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      if (editingId) {
        await API.put(`/employees/${editingId}`, {
          name: form.name,
          department: form.department,
          salary: form.salary ? Number(form.salary) : null,
          hire_date: form.hire_date || null,
        });
      } else {
        await API.post("/employees", {
          ...form,
          salary: form.salary ? Number(form.salary) : null,
        });
      }
      cancelEdit();
      loadEmployees();
    } catch (err) {
      setError(err.response?.data?.detail || "Something went wrong");
    }
  };

  const remove = async (id) => {
    if (!confirm("Delete this employee?")) return;
    await API.delete(`/employees/${id}`);
    loadEmployees();
  };

  return (
    <div style={{ maxWidth: 900, margin: "40px auto", fontFamily: "system-ui, sans-serif", padding: "0 16px" }}>
      <h1>Employee Manager</h1>

      <form onSubmit={submit} style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>
        <input placeholder="Name" value={form.name} onChange={handleChange("name")} required />
        <input
          placeholder="Email"
          type="email"
          value={form.email}
          onChange={handleChange("email")}
          disabled={!!editingId}
          required
        />
        <input placeholder="Department" value={form.department} onChange={handleChange("department")} />
        <input placeholder="Salary" type="number" value={form.salary} onChange={handleChange("salary")} />
        <input
          type="date"
          value={form.hire_date}
          onChange={handleChange("hire_date")}
          disabled={!!editingId}
        />
        <button type="submit">{editingId ? "Update" : "Add"} Employee</button>
        {editingId && (
          <button type="button" onClick={cancelEdit}>
            Cancel
          </button>
        )}
      </form>

      {error && <p style={{ color: "crimson" }}>{error}</p>}
      {loading && <p>Loading...</p>}

      <table width="100%" cellPadding="8" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ textAlign: "left", borderBottom: "2px solid #ddd" }}>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Salary</th>
            <th>Hire Date</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id} style={{ borderBottom: "1px solid #eee" }}>
              <td>{emp.name}</td>
              <td>{emp.email}</td>
              <td>{emp.department}</td>
              <td>{emp.salary}</td>
              <td>{emp.hire_date}</td>
              <td style={{ display: "flex", gap: 6 }}>
                <button onClick={() => startEdit(emp)}>Edit</button>
                <button onClick={() => remove(emp.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
